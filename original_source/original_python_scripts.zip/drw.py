"""Damped Random Walk (CAR(1); Kelly et al. 2009) continuum and top-hat BLR echo simulator."""
import numpy as np

def simulate_drw(t_grid, tau=50.0, sf_inf=0.2, mean=1.0, seed=None):
    """Simulate a DRW light curve on an arbitrary sorted time grid."""
    rng = np.random.default_rng(seed)
    sigma = sf_inf / np.sqrt(tau / 2.0)

    n = len(t_grid)
    x = np.zeros(n)
    x[0] = mean + sigma * np.sqrt(tau / 2.0) * rng.standard_normal()

    for i in range(1, n):
        dt = t_grid[i] - t_grid[i - 1]
        a = np.exp(-dt / tau)
        x[i] = (x[i - 1] * a
                + mean * (1 - a)
                + sigma * np.sqrt(1 - a**2) * rng.standard_normal())
    return x


def echo_light_curve(t_grid, continuum, lag, tophat_width, scale=1.0, extra_scatter=0.0, seed=None):
    """BLR line light curve: continuum shifted by `lag` and convolved with a top-hat of `tophat_width`."""
    rng = np.random.default_rng(seed)
    dt = np.median(np.diff(t_grid))
    t_fine = np.arange(t_grid[0], t_grid[-1] + dt, dt / 4.0)
    cont_fine = np.interp(t_fine, t_grid, continuum)

    half = tophat_width / 2.0
    kernel_t = np.arange(-half, half + dt / 4.0, dt / 4.0)
    kernel = np.ones_like(kernel_t)
    kernel /= kernel.sum()

    shifted = np.interp(t_fine - lag, t_fine, cont_fine, left=cont_fine[0], right=cont_fine[-1])
    line_fine = np.convolve(shifted, kernel, mode='same')

    line = np.interp(t_grid, t_fine, line_fine) * scale
    if extra_scatter > 0:
        line += extra_scatter * np.nanstd(line) * rng.standard_normal(len(line))
    return line
