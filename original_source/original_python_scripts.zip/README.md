# Cadence, CubeSats, and Certainty

Simulation code for "Cadence, CubeSats, and Certainty: How Constellation Size Affects
Reverberation-Mapped Black Hole Mass Uncertainty" (Aisha Shermatova). Paper: `paper.pdf`.

Pipeline: DRW continuum -> top-hat BLR echo -> cadence sampling + noise -> ICCF lag -> FR/RSS uncertainty -> virial mass.

## Setup
    pip install -r requirements.txt

## Modules (imported, not run directly)
- `drw.py` - Damped Random Walk + echo light curve
- `iccf.py` - ICCF and FR/RSS
- `simulation_core.py` - shared realization/configuration runners
- `orbital_visibility.py` - occultation, Sun-avoidance, eclipse, downlink model

## Scripts (run from this folder; figures go to `figures/`)
| Script | Produces | Paper |
|---|---|---|
| `run_simulation.py` | baseline table, `results.json` | Sec 3.1, Table 1 |
| `generate_figures.py` | fig1-fig5 | Sec 3.1 |
| `sensitivity_analysis.py` | fig6-fig7, `sensitivity_results.json` | Sec 3.2, Tables 2-3 |
| `realistic_orbital_analysis.py` | fig8-fig9, occultation-only results | Sec 3.3, Table 4 |
| `full_constraints_analysis.py` | fig11-fig12, four-constraint results | Sec 3.3, Table 4 |
| `mc_convergence_test.py` | fig10 | Sec 2.6 footnote |

Runs are slow (many Monte Carlo trials). Seeds are fixed, so results are reproducible.
